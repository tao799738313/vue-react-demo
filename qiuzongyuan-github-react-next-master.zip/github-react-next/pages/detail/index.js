import dynamic from 'next/dynamic'
import MarkdowmIt  from 'markdown-it'
import withRepoBasic from '../../components/with-repo-basic'
import { request } from '../../lib/dealRquest'
const MarkdownRender = dynamic(() => import('../../components/MarkdownRender'),
  {
    loading: () => <p>Loading</p>
  })
const md = new MarkdowmIt({
  html: true,
  linkify: true
})
const Detail = ({ readme }) => {
  return(
    <MarkdownRender content={readme.content} isBase64={true} />
  )
}

Detail.getInitialProps = async (ctx) => {
  const { req, res, query:{owner, name} } = ctx
  
  const readmeResp = await request({
    url: `/repos/${owner}/${name}/readme`
  } ,req ,res)
  
  return {
    readme: readmeResp.data
  }
}
export default withRepoBasic(Detail, 'index')
