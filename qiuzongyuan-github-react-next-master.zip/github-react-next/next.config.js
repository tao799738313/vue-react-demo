const webpack = require('webpack')
const withBundleAnalyzer = require('@zeit/next-bundle-analyzer')
const withCSS = require('@zeit/next-css')
const AuthConfig = require('./server/AuthConfig')
if(typeof require !== 'undefined') {
  require.extensions['.css'] = file => {
  }
}
const GIHUB_OAUTH_URL = 'https://github.com/login/oauth/authorize'
const SCOPE = 'user'
module.exports = withBundleAnalyzer(
  withCSS({
    webpack(config) {
      config.plugins.push(new webpack.IgnorePlugin(/^\.\/locale$/, /moment$/))
      return config
    },
    publicRuntimeConfig: {
      GIHUB_OAUTH_URL,
      OAUTH_URL: `${GIHUB_OAUTH_URL}?client_id=${AuthConfig.github.client_id}&scope=${SCOPE}`
    },
    analyzeBrowser: ['browser', 'both'].includes(process.env.BUNDLE_ANALYZE),
    bundleAnalyzerConfig: {
      server: {
        analyzerMode: 'static',
        reportFilename: '../bundles/server.html',
      },
      browser: {
        analyzerMode: 'static',
        reportFilename: '../bundles/client.html',
      },
    },
  }),
)
