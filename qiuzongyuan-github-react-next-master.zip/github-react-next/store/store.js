import { createStore, applyMiddleware } from 'redux'
import { composeWithDevTools } from 'redux-devtools-extension'
import thunk from 'redux-thunk'

import mainReducer from './reducers'

const makeStore = (initialState , options) =>{
  let initialGlobalState  = {}
  let userInfo
  if (options.req) {
    userInfo = options.req.session.userInfo
    initialGlobalState.user = userInfo
  }
  return createStore(
    mainReducer,
    Object.assign({}, initialState,initialGlobalState),
    composeWithDevTools(applyMiddleware(thunk))
  )
}
export default makeStore
