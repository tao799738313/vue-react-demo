import { LOGOUT } from '../actions/actionTypes'

const userInitialState = {}

export default (state = userInitialState, action) => {
  switch (action.type) {
    case LOGOUT:
      return {}
    default:
      return state
  }
}
