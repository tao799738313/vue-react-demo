import {LOGOUT} from './actionTypes'
import axios from 'axios'

export const logout= () => {
  // return {
  //   type: LOGOUT
  // }
  return  async (dispatch) => {
    // axios({
    //   method: 'POST',
    //   url: '/api/logout'
    // }).then(res => {
    //   dispatch({ type: LOGOUT})
    // })
    // await axios({
    //   method: 'POST',
    //   url: '/api/logout'
    // })
    await  axios.post('/api/logout')
    dispatch({ type: LOGOUT })
  }
}
