export const LOGOUT = 'LOGOUT'
