module.exports = {
  github: {
    client_id: 'a60033ff2eaa1dc4a61d',
    client_secret: 'c0aba39d56dfac79612503c3651857ce3bfd787e',
    
  }
}
