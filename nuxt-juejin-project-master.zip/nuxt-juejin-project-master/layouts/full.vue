<template>
  <div style="background-color: #f4f4f4;min-height: 100vh;">
    <top-bar></top-bar>
    <nuxt />
  </div>
</template>

<script>
export default {
}
</script>

<style>
</style>
